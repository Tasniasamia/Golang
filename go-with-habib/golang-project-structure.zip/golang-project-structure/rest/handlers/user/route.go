package user;

import (
	"net/http"

	"mains/rest/middleware"

)

func (h *Handler) UserRoutes(mux *http.ServeMux, manager *middleware.Manager) {

	mux.Handle("POST /resister", manager.With(http.HandlerFunc(h.CreateUser)));
	mux.Handle("POST /login", manager.With(http.HandlerFunc(h.Login)));

}