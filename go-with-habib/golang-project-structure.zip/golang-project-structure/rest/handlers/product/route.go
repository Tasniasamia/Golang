package product;

import (
	"net/http"
     "mains/rest/middleware"

)

func (h *Handler) ProductRoutes(mux *http.ServeMux, manager *middleware.Manager) {
	// mux.HandleFunc("GET /", manager.With(http.HandlerFunc(handler.GetProducts)).ServeHTTP);
	// mux.HandleFunc("POST /product", manager.With(http.HandlerFunc(handler.CreateProduct)).ServeHTTP)
	// mux.HandleFunc("GET /product/{id}", manager.With(http.HandlerFunc(handler.GetSingleProduct)).ServeHTTP)
	
	mux.Handle("GET /", manager.With(http.HandlerFunc(h.GetProducts)));
	mux.Handle("POST /product", manager.With(http.HandlerFunc(h.CreateProduct), middleware.AuthMiddleware));
	mux.Handle("GET /product/{id}", manager.With(http.HandlerFunc(h.GetSingleProduct)));
	mux.Handle("PUT /product/{id}", manager.With(http.HandlerFunc(h.UpdateProduct), middleware.AuthMiddleware));
	mux.Handle("DELETE /product/{id}", manager.With(http.HandlerFunc(h.DeleteProduct), middleware.AuthMiddleware));
	

}