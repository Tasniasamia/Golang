package rest

import (
	"fmt"
	"mains/config"
	"mains/rest/handlers/product"
	"mains/rest/handlers/user"
	"mains/rest/middleware"
	"net/http"
)

type Server struct{

  ProductHandler *product.Handler;
  UserHandler *user.Handler;


}

func CreateServer( ProductHandler *product.Handler, UserHandler *user.Handler) *Server {
	return &Server{
	
		ProductHandler: ProductHandler,
		UserHandler: UserHandler,
	}
}



func (s *Server) Start() {
   mux := http.NewServeMux()
	
   managerStruct :=middleware.NewManager();

   managerStruct.Use(middleware.Logger, middleware.Hudai,middleware.Preflight,middleware.Cors)
   
   globalRoute :=managerStruct.WrappedMux(mux);



	s.ProductHandler.ProductRoutes(mux, managerStruct)
	s.UserHandler.UserRoutes(mux, managerStruct)

	// s.cnf.HTTP_PORT="8990"  //possiable to change


	fmt.Println("Server is running on : ", config.GetConfig().HTTP_PORT);  
    address :=":"+config.GetConfig().HTTP_PORT
	err := http.ListenAndServe(address, globalRoute)
	if err != nil {
		fmt.Println("Error starting server:", err)
		panic(err)
	}
}