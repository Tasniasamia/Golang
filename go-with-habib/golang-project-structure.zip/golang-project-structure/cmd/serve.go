package cmd;
import (

	"mains/rest"
	"mains/rest/handlers/product"
	"mains/rest/handlers/user"
  


)
func Serve() {

    productHandler :=product.NewHandler();
	userHandler :=user.NewHandler();
	server :=rest.CreateServer(productHandler, userHandler);
	server.Start()
}
